# Small subset of the Kuzushiji-Kanji (KKanji) dataset

This directory contains 1000 randomly selected images of the Kuzushiji-Kanji (KKanji), which is part of the "KMNIST Dataset" and licensedCC BY-SA 4.0 license:
- "KMNIST Dataset" (created by CODH), adapted from "Kuzushiji Dataset" (created by NIJL and others), doi:10.20676/00000341.

The random subset was generated with the following code:

```python
import os
import PIL

path_to_kkanji2 = '/path/to/kkanji2/directory'

rng = np.random.RandomState(seed=20230619)

subdirs = sorted(os.listdir(path_to_kkanji2))
chosen_subdirs = rng.choice(subdirs, 1000, replace=False)

all_imgs = []
os.mkdir('data/kkanji2')
with open('data/kkanji2/sourcemap.csv', 'w') as sourcmap:
    for i, dir_name in enumerate(chosen_subdirs):
        file_names = sorted(os.listdir(f'{path_to_kkanji2}/{dir_name}/'))
        file_name = rng.choice(file_names)
        with PIL.Image.open(f'{path_to_kkanji2}/{dir_name}/{file_name}') as img:
            all_imgs.append(np.asarray(img))
        sourcmap.write(f'{i},{dir_name}/{file_name}\n')

all_imgs = np.stack(all_imgs)
np.savez_compressed('data/kkanji2/smallkkanji2.npz', data=all_imgs)
```
